import note from "./note"

export default {
	note
}