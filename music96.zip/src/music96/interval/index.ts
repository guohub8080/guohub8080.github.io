import getIntervalByComparingNotes from "./methods/getIntervalByComparingNotes.ts";
export {getIntervalByComparingNotes} from "./methods/getIntervalByComparingNotes.ts";
export {Interval} from "./cls/IntervalClass.ts"
export default {
	getIntervalByComparingNotes
}