import {t_intervalType_145, t_intervalType_2367} from "./types";

export const intervalTypeList_145: t_intervalType_145[] = ["dim-", "dim", "p", "aug", "aug+"]
export const intervalTypeList_2367: t_intervalType_2367[] = ["dim-", "dim", "min", "maj", "aug", "aug+"]