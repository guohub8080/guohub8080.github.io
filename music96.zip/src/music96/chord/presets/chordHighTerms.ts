const chordHighTerms = {
  "dom9": "dom9",
  "dom9b13": "dom9b13",
  "maj9": "maj9",
  "maj9sus4": "maj9sus4",
  "maj9#11": "maj9#11",
  "min9": "min9",
  "mM9": "mM9",
  "dom11": "dom11",
  "dom11b9": "dom11b9",
  "maj11": "maj11",
  "min11": "min11",
  "dom13": "dom13",
  "dom13#9": "dom13#9",
  "maj13": "maj13",
  "min13": "min13",
}

export default chordHighTerms