const chord3Terms = {
  "maj3": "maj3",
  "maj3b5": "maj3b5",
  "min3": "min3",
  "dim3": "dim3",
  "aug3": "aug3",
  "sus2": "sus2",
  "sus4": "sus4",
}

export default chord3Terms