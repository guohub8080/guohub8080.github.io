const getNote = ()=>{
  return
}
export default getNote