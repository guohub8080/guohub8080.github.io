import noteScoreTypeValues from "../../static/noteScoreTypeValues.ts";

const cls_getNotationType = (quarterLength: number) => {
  return
}

export default cls_getNotationType