// noinspection ES6PreferShortImport

export class Score {
	public title: string;

	constructor(title?: string) {
		this.title = title
	}
}