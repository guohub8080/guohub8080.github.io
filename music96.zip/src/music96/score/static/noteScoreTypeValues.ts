// noinspection ES6PreferShortImport

const noteScoreTypeValues = {
	"16th": "16th",
	"eighth": "eighth",
	"quarter": "quarter",
	"half": "half",
	"whole": "whole"
}

export default noteScoreTypeValues