import {getFifthCircleByCircleId} from "./methods/getFifthCircle";

export default {getFifthCircleByCircleId}