/// <reference types="vite/client" />
declare module '*.tsx'
declare module '*.jsx'
declare module '*.js'
declare module '*.ts'