import note from "./note"
import interval from "./interval"

export default {
    note: {...note},
    interval: {...interval}
}