export default {
	flexCenter:{
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
	},
	normalTransition:{transition:"all ease 0.2s"},
}