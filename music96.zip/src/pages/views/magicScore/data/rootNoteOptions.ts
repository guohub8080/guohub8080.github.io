// noinspection ES6PreferShortImport

export default [{value: ["C", 0], label: "C"}, {value: ["C", 1], label: "C♯"},
	{value: ["D", -1], label: "D♭"}, {value: ["D", 0], label: "D"},
	{value: ["D", 1], label: "D♯"}, {value: ["E", -1], label: "E♭"},
	{value: ["E", 0], label: "E"}, {value: ["F", 0], label: "F"},
	{value: ["F", 1], label: "F♯"}, {value: ["G", -1], label: "G♭"},
	{value: ["G", 0], label: "G"}, {value: ["G", 1], label: "G♯"},
	{value: ["A", -1], label: "A♭"}, {value: ["A", 0], label: "A"},
	{value: ["A", 1], label: "A♯"}, {value: ["B", -1], label: "B♭"},
	{value: ["B", 0], label: "B"}]