export type i18n_type = {
	en: string,
	cn: string
}